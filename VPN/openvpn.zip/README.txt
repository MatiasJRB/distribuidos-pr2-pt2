1. Update the Raspberry Pi

sudo apt-get update
sudo apt-get upgrade

2. Install OpenVPN

sudo apt-get install openvpn unzip

3. Verificar la zona horaria (seleccionar la correcta)

sudo dpkg-reconfigure tzdata

5. Elevate your privileges to root

sudo -i 

6. Descomprimir el zip

unzip openvpn.zip

7. Iniciar openVPN

sudo openvpn --config VPNConfig.conf  

Credenciales:
usuario: userDistri
pass: .Udpc5j.